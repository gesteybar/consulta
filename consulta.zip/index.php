<? session_name('cons'); session_start(); ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<title>Consulta</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css" href="./css/gral.css">
	<link rel="shortcut icon" type="image/x-icon" href="./imagenes/logo.ico">
	<script type="text/javascript" src="./js/frame.js"></script>
	<script type="text/javascript" src="./js/permisos.js"></script>
	<script type="text/javascript">
		function login() {
			var usuario=getValue('txtUsuario');
			var pass=getValue('txtPass');

			oAjax.request="login&usuario="+usuario+"&pass="+pass;
			oAjax.send(resp);

			function resp(data) {
				if (data.responseText!='ok') {
					alert('Credenciales no válidas');
					return false;
				}
				location.reload();
			}
		}

		function setProf() {

		}
	</script>
</head>
<body>
	<? if (!isset($_SESSION['idUsuario'])) {?>
	<div id="divLogin">
		<div id="header">
			<img src="./imagenes/logo1.png">
			<p id="tituloLogo">CRECER Consultorios</p>
		</div>
		<table id="tblLogin">
			<tr>
				<td>Usuario:</td>
				<td><input type="text" id="txtUsuario" placehoder="Ingrese usuario"></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input type="password" id="txtPass"></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><button type="submit" class="botonok" onclick="login();">Ingresar</button></td>
			</tr>
		</table>
	</div>
	<? } else {?>
	<div id="divMain">
	<? include('header.php'); ?>
		<div id="content">
		<? switch ($_SESSION['perfil']) {
			case "A":
				echo '<a href="https://docs.google.com/spreadsheets/d/1anuElaoQkGukyq_7zor5QIaTvRGjxi17BkEY61DTnFw/edit#gid=1154238927">Planilla</a>';
				break;
			case "R":?>
					<div id="frmNuevoTurno" class="ventanaInicio">
						<h2>Buscar Paciente</h2>
						<input type="hidden" id="hidTurno">
						<table id="tblNTur">
							<tr>
								<td>Paciente:</td>
								<td colspan="4">
									<input type="hidden" id="hidPaciente">
								
								
									<select id="cboDoc"><option value="N">Nombre</option><option value="D">DNI</option><option value="S">Socio</option><option value="H">Hist. Clínica</option></select>
									<input id="txtDNI" type="text">
									<button id="cmdBuscarPaciente" type="button" class="botonok" onclick="buscarPaciente();"><img src="./imagenes/lupa.png"></button>
									<button id="cmdNuevoPaciente" type="button" class="botonok" onclick="altaPaciente();"><img src="./imagenes/nueva.png" width="16"></button>

								</td>
								</td>
							</tr>
								<td colspan="2" align="center">
									<button class="botonok" type="button" onclick="ingresarTurno();">Aceptar</button>
									<button class="botoncancel" type="button" onclick="cerrar('frmNuevoTurno');">Cancelar</button>
								</td>
							</tr>
						</table>
					</div>
					<div class="ventanaInicio">
						
					</div>
		<?		break;
		}
			
			
		?>
		</div>
	</div>
	<?}?>

</body>
</html>